<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class CreateAdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      $user = new User();
      $user->name = 'admin';
      $user->user_name  = 'admin123';
      $user->email = 'admin@gmail.com';
      $user->password = Hash::make('testing123123');
      $user->user_role = 'admin';
      $user->save();

      return back();
    }
}
