<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\admin\AdminController;
use App\Http\Controllers\API\admin\LoginController;
use App\Http\Controllers\API\user\LoginController as UserLoginController;
use App\Http\Controllers\API\user\RegisterController;
use App\Http\Controllers\API\user\UserProfileController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::prefix('admin')->group(function () {
  Route::post('login', [LoginController::class, 'Login']);
  Route::middleware(['auth:api','admin_middleware'])->group( function () {
    Route::post('invite-user', [AdminController::class, 'InviteUser']);
  });
});

Route::prefix('user')->group(function () {
  Route::post('register/{user_email}', [RegisterController::class, 'Register']);
  Route::post('login', [UserLoginController::class, 'Login']);
  Route::middleware(['auth:api'])->group( function () {
    Route::post('enterotp', [RegisterController::class, 'EnterOtp']);
    Route::middleware(['otpcheck_middleware'])->group( function () {
      Route::get('viewprofile', [UserProfileController::class, 'ViewProfile']);
      Route::post('updateprofile', [UserProfileController::class, 'UpdateProfile']);
    });
  });
});

