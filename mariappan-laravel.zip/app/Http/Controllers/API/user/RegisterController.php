<?php

namespace App\Http\Controllers\API\user;

use App\Http\Controllers\API\ResponseController as ResponseController;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Mail\OtpMail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;

class RegisterController extends ResponseController
{
  public function Register(Request $request,$user_email)
  {
    $validator = Validator::make($request->all(), [
      'user_name' => [
        'required',
        'string',
        'min:4',
        'max:20',
        Rule::unique('users', 'user_name')
      ],
      'password' => 'required'
    ]);

    if($validator->fails()){
      return $this->sendError(
        'register_validation', 
        $validator->errors(),
        400
      );
    }

    $user = new User();
    $user->user_name = $request->user_name;
    $user->password = Hash::make($request->password);
    $user->email = $user_email;
    $user->otp = $this->GenerateOtp();
    $user->save();

    $success['user_name'] =  $user->user_name;
    $success['email'] =  $user->email;
    $success['token'] =  $user->createToken('MyApp')->accessToken;

    $this->SendOtpToEmail($user);

    return $this->sendResponse(
      $success, 
      'OTP sended to corresponding email !'
    );
  }

  public function EnterOtp(Request $request)
  {
    if (User::where('id',Auth::user()->id)->whereNotNull('registered_at')->exists()) {

      return $this->sendError( 
        'OTP procedure already done in this account', 
        ['error'=>'Unauthorised'],
        401
      );

    }

    $validator = Validator::make($request->all(), [
      'otp' => [
        'required',
        'integer',
        'digits:6'
      ],
    ]);

    if($validator->fails()){
      return $this->sendError(
        'OTP validation', 
        $validator->errors(),
        400
      );
    }

    $user = User::find(Auth::user()->id);
    
    if ($user->otp == $request->otp) {

      $user->registered_at = Carbon::now();
      $user->otp = null;
      $user->save();

    }else{
      return $this->sendError(
        'Wrong Otp Code', 
        [],
        400
      );
    }

    return $this->sendResponse(
      $user, 
      'Account Created Successfully'
    );
  }

  public function GenerateOtp()
  {
    do {
      $otp = random_int(100000, 999999);
    } while (User::where('otp', $otp)->first());

    return $otp;
  }

  public function SendOtpToEmail($user)
  {
    $details = [
      'user_name' => $user->user_name,
      'otp' => $user->otp,
    ];

    mail::to($user->email)->send(new OtpMail($details));

    return ;
  }
}
