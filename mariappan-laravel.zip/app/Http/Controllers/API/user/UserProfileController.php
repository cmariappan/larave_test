<?php

namespace App\Http\Controllers\API\user;

use App\Http\Controllers\API\ResponseController as ResponseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\File;

class UserProfileController extends ResponseController
{
  public function ViewProfile()
  {
    $user = User::where('id',Auth::user()->id)
        ->first();

    return $this->sendResponse(
      $user,
      'Profile Viewed',
    );
  }

  public function UpdateProfile(Request $request)
  {
    $user = User::where('id',Auth::user()->id)
        ->first();

    $validator = Validator::make($request->all(), [
      'user_name' => [
        'required',
        'string',
        'min:4',
        'max:20',
        Rule::unique('users', 'user_name')->ignore(Auth::user())
      ],
      'name' => 'nullable|string',
      'email' => 'required|email',
      'password' => 'required',
    ]);

    if($validator->fails()){
      return $this->sendError(
        'please fill required fields', 
        $validator->errors(),
        400
      );
    }

    if ($request->hasFile('avatar')) {
      
      $validator = Validator::make($request->all(), [
        'avatar' => 'required|image|mimes:jpeg,png,jpg|max:2048'
      ]);
      
      if($validator->fails()){
        return $this->sendError(
          'please fill required fields', 
          $validator->errors(),
          400
        );
      }

      if ($user->avatar !== null) {

        $oldimage = $user->avatar;

        File::delete($oldimage); 
      }
      

      $image = $request->file('avatar');
      $imagename = 'user/' . time().'.'.$image->getClientOriginalExtension();
      $destinationPath = 'user/';
      $image->move($destinationPath, $imagename);
      $user->avatar = $imagename; 
    }

    $user->user_name = $request->user_name;
    $user->name = $request->name;
    $user->password = Hash::make($request->password);
    $user->email = $request->email;
    $user->save();

    return $this->sendResponse(
      $user,
      'Profile Updated',
    );
  }

  public function UpdateProfileAvatar(Request $request)
  {
    $user = User::where('id',Auth::user()->id)
        ->select(
          'name',
          'user_name',
          'email',
          'avatar'
        )
        ->first();
        
    $validator = Validator::make($request->all(), [
      'avatar' => 'required|mimes:jpeg,png,jpg|max:100000'
    ]);
    
    if($validator->fails()){
      return $this->sendError(
        'please fill required fields', 
        $validator->errors(),
        400
      );
    }


    if ($request->hasFile('avatar')) {

      $image = $request->file('avatar');
      $imagename = '/user/' . time().'.'.$image->getClientOriginalExtension();
      $destinationPath = 'user';
      $image->move($destinationPath, $imagename);


      $user->image = $imagename;  
    }

    return $this->sendResponse(
      $user,
      'Profile Avatar Updated',
    );
  }
}
