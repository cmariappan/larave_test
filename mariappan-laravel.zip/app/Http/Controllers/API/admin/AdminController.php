<?php

namespace App\Http\Controllers\API\admin;

use App\Http\Controllers\API\ResponseController as ResponseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use App\Mail\InviteMail;

class AdminController extends ResponseController
{
  public function InviteUser(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'email' => 'required|email',
    ]);

    if($validator->fails()){
      return $this->sendError(
        'Please Check Required Fields', 
        $validator->errors(),
        400
      );       
    }

    $details = [
      'email' => $request->email,
    ];

    mail::to($request->email)->send(new InviteMail($details));
    
    return $this->sendResponse(
      [],
      'Invite Mail Sended to ' . $request->email,
    );
  }
}
