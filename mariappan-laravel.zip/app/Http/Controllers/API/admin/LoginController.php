<?php

namespace App\Http\Controllers\API\admin;

use App\Http\Controllers\API\ResponseController as ResponseController;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class LoginController extends ResponseController
{
  public function Login(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'user_name' => 'required|string',
      'password' => 'required'
    ]);

    if($validator->fails()){
      return $this->sendError(
        'please fill required fields', 
        $validator->errors(),
        400
      );
    }

    if(Auth::attempt(['user_name' => $request->user_name, 'password' => $request->password])){
      $user = Auth::user();
      $success['token'] =  $user->createToken('MyApp')->accessToken;
      $success['name'] =  $user->name;
      $success['user_name'] =  $user->user_name;
      $success['id'] =  $user->id;
      if ($user->user_role != "admin") {
        return $this->sendError(
          'access denied', 
          ['error'=>'Unauthorised'], 
          401
        );
      }

      return $this->sendResponse(
        $success,
        'you are logged in successfully'
      );
    }
    else{
      return $this->sendError( 
        'incorrect email or password', 
        ['error'=>'Unauthorised'],
        401
      );
    }
  }
}
